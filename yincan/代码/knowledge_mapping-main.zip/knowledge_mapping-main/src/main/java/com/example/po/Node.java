package com.example.po;


public interface Node {

    Long getId();
    String getLabel();
}
