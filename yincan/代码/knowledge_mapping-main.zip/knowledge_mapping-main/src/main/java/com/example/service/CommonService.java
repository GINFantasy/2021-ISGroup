package com.example.service;

import com.example.po.Node;
import com.example.vo.Result;

public interface CommonService {




    Node getNodeById(Long id) ;
}
