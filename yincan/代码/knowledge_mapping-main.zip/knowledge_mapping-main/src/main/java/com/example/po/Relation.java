package com.example.po;


public interface Relation{
    Node getSrc();
    Node getDest();

}
